﻿using ConsoleApp.Models;
using System;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {

            using (var context = new SampleDbContext())
            {
                for (int i = 1; i <= 100000; i++)
                {
                    Employee employee = new Employee();

                    employee.EmployeeId = Guid.NewGuid();
                    employee.Name = "Name" + i;
                    employee.Department = "Dept" + i;
                    employee.City = "Blr" + i;
                    employee.Gender = "M";
                    context.Employee.Add(employee);
                }
                context.SaveChanges();
            }
            using (var context= new SampleDbContext())
            {
                for (int i = 1; i <= 1000000; i++)
                {
                    Test test = new Test();

                    test.Userid = i;
                    test.Name = "TestName" + i;

                    context.Test.Add(test);
                }

                context.SaveChanges();
            }
        }
    }
}
