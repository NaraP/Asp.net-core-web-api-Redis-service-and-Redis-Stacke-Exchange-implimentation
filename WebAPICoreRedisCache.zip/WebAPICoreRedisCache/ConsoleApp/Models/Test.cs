﻿using System;
using System.Collections.Generic;

namespace ConsoleApp.Models
{
    public partial class Test
    {
        public int Userid { get; set; }
        public string Name { get; set; }
    }
}
