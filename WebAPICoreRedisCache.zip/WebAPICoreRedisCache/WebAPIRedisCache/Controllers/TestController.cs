﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAPIRedisCache.Models;
using WebAPIRedisCache.Services;

namespace WebAPIRedisCache.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        private readonly ITestService _testService;
        public TestController(ITestService testService)
        {
            _testService = testService;
        }

        [HttpGet("GetTestDataList", Name = nameof(GetTestDataList))]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        public async Task<ActionResult> GetTestDataList()
        {
            var result = await _testService.GetAllTestData();

            return StatusCode((int)result.StatusCode, result.returnObj);
        }
    }
}