﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIRedisCache.RedisHelper
{
    public interface IRedisStackexChange
    {
        Task<bool> IsKeyExists(string key);
        Task<bool> Add(string key, object value);
        // string GetStrings(string key, string value);
        // bool StoreList<T>(string key, T value, TimeSpan timeout);
        Task<List<T>> GetList<T>(string key);
        Task<bool> RemoveStrings(string key);
    }
}
