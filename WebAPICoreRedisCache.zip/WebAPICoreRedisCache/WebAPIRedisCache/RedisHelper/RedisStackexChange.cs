﻿using StackExchange.Redis.Extensions.Core.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIRedisCache.RedisHelper
{
    public class RedisStackexChange : IRedisStackexChange
    {
        private readonly IRedisCacheClient _redis;

        public RedisStackexChange(IRedisCacheClient redis)
        {
            _redis = redis;
        }

        public async Task<bool> Add(string key, object value)
        {
             bool added = false;

             added = await _redis.Db0.AddAsync(key, value, DateTimeOffset.Now.AddMinutes(10));

            if (added == true)
            {
                return true;
            }
            return added;
        }

        public async Task<List<T>> GetList<T>(string key)
        {
            List<T> resultData = new List<T>();

            var redisData = await  _redis.Db0.GetAllAsync<T>(new string[] { key });

            var result = redisData.Values.ToList();

            return result;
        }

        //public string GetStrings(string key, string value)
        //{
        //    throw new NotImplementedException();
        //}

        public async Task<bool> IsKeyExists(string key)
        {
            return await _redis.Db0.ExistsAsync(key);
        }

        public async Task<bool> RemoveStrings(string key)
        {
            var result = await _redis.Db0.RemoveAsync(key);

            return result;
        }

        //public bool StoreList<T>(string key, T value, TimeSpan timeout)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
