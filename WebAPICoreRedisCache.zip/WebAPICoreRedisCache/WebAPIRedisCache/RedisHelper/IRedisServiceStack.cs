﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIRedisCache.RedisHelper
{
    public interface IRedisServiceStack
    {
        bool IsKeyExists(string key);
        void SetStrings(string key, string value);
        string GetStrings(string key, string value);
        bool StoreList<T>(string key, T value, TimeSpan timeout);
        T GetList<T>(string key);
        void RemoveStrings(string key);
        long Increment(string key);
        long Decrement(string key);
    }
}
