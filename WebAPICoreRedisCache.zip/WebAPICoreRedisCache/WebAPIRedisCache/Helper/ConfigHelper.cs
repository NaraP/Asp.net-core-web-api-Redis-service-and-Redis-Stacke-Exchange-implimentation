﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIRedisCache.Helper
{
    public class ConfigHelper
    {
        public static IConfigurationRoot GetConnectionSection()
        {
            var builder = new ConfigurationBuilder()
                            .SetBasePath(Directory.GetCurrentDirectory())
                            .AddJsonFile("appsettings.json", true, true);
            var configuration = builder.Build();

            return configuration;
        }
    }
}
