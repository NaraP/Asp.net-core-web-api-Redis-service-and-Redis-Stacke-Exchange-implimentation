﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using WebAPIRedisCache.Helper;
using WebAPIRedisCache.Models;
using WebAPIRedisCache.RedisHelper;

namespace WebAPIRedisCache.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly SampleDbContext _sampleDbContext;
        private readonly IRedisStackexChange _redisStackexChange;

        public EmployeeService(SampleDbContext sampleDbContext, IRedisStackexChange redisStackexChange)
        {
            _sampleDbContext = sampleDbContext;
            _redisStackexChange = redisStackexChange;
        }

        public async Task<ResponseMessage> GetAllEmployeesData()
        {
            var responseMessage = new ResponseMessage();

            try
            {
                var isCachedData = _redisStackexChange.IsKeyExists("empdata");

                if (isCachedData.Result == true)
                {
                    var employeeData = _redisStackexChange.GetList<List<Employee>>("empdata");

                    responseMessage.returnObj = employeeData.Result.ToList();
                        
                    responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.OK);
                    responseMessage.StatusDescription = Convert.ToString(HttpStatusCode.OK);
                    return responseMessage;
                }
                else
                {
                    var empResultData = await _sampleDbContext.Employee.ToListAsync();

                    await _redisStackexChange.Add("empdata", empResultData);

                    responseMessage.returnObj = empResultData;
                    responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.OK);
                    responseMessage.StatusDescription = Convert.ToString(HttpStatusCode.OK);
                    return responseMessage;
                }
            }
            catch (Exception ex)
            {
            }

            return responseMessage;
        }
    }
}
