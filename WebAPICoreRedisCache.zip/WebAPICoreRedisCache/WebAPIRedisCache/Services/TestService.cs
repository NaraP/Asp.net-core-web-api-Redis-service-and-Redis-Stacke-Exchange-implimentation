﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using WebAPIRedisCache.Helper;
using WebAPIRedisCache.Models;
using WebAPIRedisCache.RedisHelper;

namespace WebAPIRedisCache.Services
{
    public class TestService : ITestService
    {
        private readonly SampleDbContext _sampleDbContext;
        private readonly IRedisServiceStack _redisServiceStack;
        
        public TestService(SampleDbContext sampleDbContext, IRedisServiceStack redisServiceStack)
        {
            _sampleDbContext = sampleDbContext;
            _redisServiceStack= redisServiceStack;
        }
        public  async Task<ResponseMessage> GetAllTestData()
        {
            var responseMessage = new ResponseMessage();

            try
            {
                if (_redisServiceStack.IsKeyExists("testData"))
                {
                    var  testData = _redisServiceStack.GetList<List<Test>>("testData");

                    responseMessage.returnObj = testData;
                    responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.OK);
                    responseMessage.StatusDescription = Convert.ToString(HttpStatusCode.OK);
                    return responseMessage;
                }
                else
                {
                    var testData = await  _sampleDbContext.Test.ToListAsync();

                    _redisServiceStack.StoreList<List<Test>>("testData", testData, TimeSpan.MaxValue);

                    responseMessage.returnObj = testData;
                    responseMessage.StatusCode = Convert.ToInt32(HttpStatusCode.OK);
                    responseMessage.StatusDescription = Convert.ToString(HttpStatusCode.OK);
                    return responseMessage;
                }
            }
            catch(Exception ex)
            {
            }

            return responseMessage;
        }
    }
}
