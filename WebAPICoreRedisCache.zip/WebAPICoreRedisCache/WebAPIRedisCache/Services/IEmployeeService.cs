﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIRedisCache.Helper;
using WebAPIRedisCache.Models;

namespace WebAPIRedisCache.Services
{
    public interface IEmployeeService
    {
        Task<ResponseMessage> GetAllEmployeesData();
    }
}
