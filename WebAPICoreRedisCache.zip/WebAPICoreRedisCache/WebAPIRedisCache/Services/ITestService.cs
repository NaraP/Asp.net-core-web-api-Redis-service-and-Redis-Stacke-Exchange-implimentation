﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIRedisCache.Helper;
using WebAPIRedisCache.Models;

namespace WebAPIRedisCache.Services
{
    public interface ITestService
    {
        Task<ResponseMessage> GetAllTestData();
    }
}
