﻿using System;
using System.Collections.Generic;

namespace WebAPIRedisCache.Models
{
    public partial class Test
    {
        public int Userid { get; set; }
        public string Name { get; set; }
    }
}
